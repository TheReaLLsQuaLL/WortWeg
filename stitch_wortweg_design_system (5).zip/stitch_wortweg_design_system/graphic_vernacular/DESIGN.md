---
name: Graphic Vernacular
colors:
  surface: '#fcf8ff'
  surface-dim: '#dad7f3'
  surface-bright: '#fcf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f5f2ff'
  surface-container: '#efecff'
  surface-container-high: '#e8e5ff'
  surface-container-highest: '#e2e0fc'
  on-surface: '#1a1a2e'
  on-surface-variant: '#474556'
  inverse-surface: '#2f2e43'
  inverse-on-surface: '#f2efff'
  outline: '#787588'
  outline-variant: '#c8c4d9'
  surface-tint: '#533cef'
  primary: '#4221de'
  on-primary: '#ffffff'
  primary-container: '#5b45f6'
  on-primary-container: '#e5e0ff'
  inverse-primary: '#c5c0ff'
  secondary: '#705d00'
  on-secondary: '#ffffff'
  secondary-container: '#fdd400'
  on-secondary-container: '#6f5c00'
  tertiary: '#005661'
  on-tertiary: '#ffffff'
  tertiary-container: '#00707d'
  on-tertiary-container: '#a1f0ff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e4dfff'
  primary-fixed-dim: '#c5c0ff'
  on-primary-fixed: '#150067'
  on-primary-fixed-variant: '#3a10d8'
  secondary-fixed: '#ffe170'
  secondary-fixed-dim: '#e9c400'
  on-secondary-fixed: '#221b00'
  on-secondary-fixed-variant: '#544600'
  tertiary-fixed: '#9cf0ff'
  tertiary-fixed-dim: '#00daf3'
  on-tertiary-fixed: '#001f24'
  on-tertiary-fixed-variant: '#004f58'
  background: '#fcf8ff'
  on-background: '#1a1a2e'
  surface-variant: '#e2e0fc'
typography:
  display-lg:
    fontFamily: Bricolage Grotesque
    fontSize: 48px
    fontWeight: '800'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Bricolage Grotesque
    fontSize: 32px
    fontWeight: '700'
    lineHeight: '1.2'
  headline-lg-mobile:
    fontFamily: Bricolage Grotesque
    fontSize: 28px
    fontWeight: '700'
    lineHeight: '1.2'
  headline-md:
    fontFamily: Bricolage Grotesque
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.3'
  body-lg:
    fontFamily: Quicksand
    fontSize: 18px
    fontWeight: '500'
    lineHeight: '1.6'
  body-md:
    fontFamily: Quicksand
    fontSize: 16px
    fontWeight: '500'
    lineHeight: '1.6'
  label-lg:
    fontFamily: Quicksand
    fontSize: 14px
    fontWeight: '700'
    lineHeight: '1.2'
  label-sm:
    fontFamily: Quicksand
    fontSize: 12px
    fontWeight: '600'
    lineHeight: '1.2'
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 4px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 32px
  gutter: 16px
  margin-mobile: 16px
  margin-desktop: 40px
---

## Brand & Style
The design system is built upon a modern 2D comic-book aesthetic tailored for a high-energy language learning experience. It bridges Turkish and German cultures through a vibrant, "ink-and-paper" digital interface. The style is characterized by expressive, hand-drawn energy, utilizing bold ink outlines to define structure and flat, saturated colors to provide clarity. 

To maintain the comic-book narrative, the UI employs halftone patterns for texture rather than gradients. The emotional response should be one of playful confidence—making the daunting task of learning German grammar feel like progressing through a graphic novel. Every interaction should feel tactile, like placing a sticker on a page or flipping through a well-loved comic.

## Colors
This design system uses a high-contrast palette anchored by a deep ink purple for all structural outlines and text. The primary purple drives the main action flow, while the yellow CTA color is reserved strictly for primary "success" or "continue" actions to ensure maximum visibility.

A specialized functional palette is assigned to German grammatical genders:
- **Der (Masculine):** Sky Blue, representing stability.
- **Die (Feminine):** Vibrant Pink, representing energy.
- **Das (Neuter):** Warm Amber, representing neutrality.

Neutral surfaces remain off-white or lavender to reduce eye strain, while the deep ink purple (#1A1A2E) is used for all borders (2px minimum) to maintain the illustrative comic look.

## Typography
The typography is a duo of character and legibility. Headlines use **Bricolage Grotesque**, a quirky, high-personality face that mimics the expressive hand-lettering found in modern graphic novels. It should be used with tight tracking and leading for a "chunky" feel.

For instructional content and vocabulary lists, **Quicksand** provides a friendly, rounded contrast. Its soft terminals balance the sharp, bold outlines of the UI components, ensuring that long-form text remains approachable and easy to digest for learners. All labels should be set in Quicksand with a heavier weight to maintain the "sticker" aesthetic.

## Layout & Spacing
The layout follows a panel-based logic, similar to a comic book grid. Containers should feel like individual frames. We use a 12-column fluid grid for desktop and a 4-column grid for mobile. 

Spacing is disciplined and modular, based on a 4px baseline. Gutters between "panels" (cards) should be generous (16px or 24px) to allow the bold ink outlines room to breathe without clashing. Content should be grouped into distinct containers with defined borders rather than floating freely, reinforcing the tactile, printed-page feel.

## Elevation & Depth
In keeping with the strictly 2D comic style, this design system avoids soft shadows, blurs, and lighting effects. Depth is communicated through:

1.  **Hard-Edge Offsets:** Buttons and cards use a solid, 100% opaque offset shadow in the ink color (#1A1A2E). Typically, this is a 4px offset to the bottom-right.
2.  **Stacking:** Elements that are "higher" in the hierarchy simply sit on top of others with a consistent 2px ink border.
3.  **Halftone Overlays:** When an element is pressed or active, a subtle halftone dot pattern can be applied as an overlay to provide visual feedback without breaking the 2D plane.

## Shapes
Shapes are "imperfectly" geometric. While we use a base roundedness of 0.5rem (8px), the bold 2px ink outline makes these shapes feel like die-cut stickers. 

- Large containers (Panels) use `rounded-xl` (24px) to feel friendly.
- Standard buttons and input fields use `rounded-lg` (16px).
- Small chips or tags use `rounded` (8px).

The heavy outline must follow the corner radius exactly, creating a "thick-to-thin" illusion only through geometry, never through varied stroke weights.

## Components
### Buttons
Buttons are the primary "Sticker" elements. They feature a 2px ink outline and a solid 4px offset shadow. On "hover," the shadow may grow slightly; on "press," the button shifts 4px down and right to cover the shadow, mimicking a physical click.

### Cards & Panels
Every card is a comic panel. They must have a white or lavender background and a 2px ink outline. For vocabulary cards, use the "Article Colors" as a top-border accent or a small corner "dog-ear" to indicate the word's gender.

### Chips & Tags
Used for Turkish-to-German word matching. These should be flat with a 1px or 2px outline. When selected, they fill with the Primary Purple and the text flips to white.

### Input Fields
Inputs are simple white boxes with a 2px ink outline. On focus, the outline changes to Primary Purple, and the offset shadow appears to make the field "pop" from the page.

### Progress Bars
Progress bars use a "filling the ink" metaphor. The track is a hollow 2px outline, and the fill is a solid Cyan or Yellow with a halftone dot pattern overlay to show movement.